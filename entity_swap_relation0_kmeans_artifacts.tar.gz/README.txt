Entity-swap relation-0 labeled artifacts

relation_idx: 0
relation_name: capital_country
sample_pairs: 50
random_state: 42
methods: ours-ilp, baseline-kmeans

Use notebook/colab_entity_swap_relation0_kmeans.ipynb for interventions only.
